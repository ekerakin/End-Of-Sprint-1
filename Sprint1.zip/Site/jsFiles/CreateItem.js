// JavaScript Document
function check(){
	var page=document.getElementById("selectType");
	if(chosedOption.value=="Musics"){
		window.open("../htmlFiles/CreateItem-Musics.hmtl");
		}
	window.onload()=check();
	}
